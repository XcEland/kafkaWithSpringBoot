package io.confluent.developer.forKafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForKafkaApplicationTests {

	@Test
	void contextLoads() {
	}

}
