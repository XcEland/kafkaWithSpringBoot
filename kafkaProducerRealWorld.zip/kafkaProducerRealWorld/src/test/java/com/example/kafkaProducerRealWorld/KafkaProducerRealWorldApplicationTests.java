package com.example.kafkaProducerRealWorld;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaProducerRealWorldApplicationTests {

	@Test
	void contextLoads() {
	}

}
