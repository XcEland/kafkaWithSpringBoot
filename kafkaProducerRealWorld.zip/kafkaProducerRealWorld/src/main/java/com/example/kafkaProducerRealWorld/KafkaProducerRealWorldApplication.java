package com.example.kafkaProducerRealWorld;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaProducerRealWorldApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaProducerRealWorldApplication.class, args);
	}

}
